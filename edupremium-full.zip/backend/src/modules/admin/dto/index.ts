export * from './approve-teacher.dto';

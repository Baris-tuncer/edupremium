export default function AdminPage() {
  return <div>Admin Test</div>;
}
